import tensorflow as tf

# Modello U-net dense
def get_model(input_size=(32,32,32), filters=32):

    inputs = tf.keras.layers.Input(shape=(input_size[0], input_size[1], input_size[2], 1), dtype='float32')
    
    # Percorso di contrazione
    c0 = tf.keras.layers.Conv3D(filters, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(inputs)
    c0 = tf.keras.layers.Dropout(0.2)(c0)
    c0 = tf.keras.layers.Conv3D(filters, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c0)
    c0 = tf.keras.layers.Dropout(0.2)(c0)
    c0 = tf.keras.layers.Conv3D(filters, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c0)
    p0 = tf.keras.layers.MaxPooling3D((2, 2, 2))(c0)

    # Percorso di contrazione
    c1 = tf.keras.layers.Conv3D(filters*2, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(p0)
    c1 = tf.keras.layers.Dropout(0.2)(c1)
    c1 = tf.keras.layers.Conv3D(filters*2, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c1)
    c1 = tf.keras.layers.Dropout(0.2)(c1)
    c1 = tf.keras.layers.Conv3D(filters*2, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c1)
    p1 = tf.keras.layers.MaxPooling3D((2, 2, 2))(c1)

    c2 = tf.keras.layers.Conv3D(filters*4, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(p1)
    c2 = tf.keras.layers.Dropout(0.2)(c2)
    c2 = tf.keras.layers.Conv3D(filters*4, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c2)
    c2 = tf.keras.layers.Dropout(0.2)(c2)
    c2 = tf.keras.layers.Conv3D(filters*4, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c2)
    p2 = tf.keras.layers.MaxPooling3D((2, 2, 2))(c2)

    c3 = tf.keras.layers.Conv3D(filters*8, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(p2)
    c3 = tf.keras.layers.Dropout(0.2)(c3)
    c3 = tf.keras.layers.Conv3D(filters*8, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c3)
    c3 = tf.keras.layers.Dropout(0.2)(c3)
    c3 = tf.keras.layers.Conv3D(filters*8, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c3)
    p3 = tf.keras.layers.MaxPooling3D((2, 2, 2))(c3)


    # Flatten and dense
    f0 = tf.keras.layers.Flatten(data_format='channels_last')(p3)
    f1 = tf.keras.layers.Dense(units=32768, activation='relu')(f0)
    f2 = tf.keras.layers.Reshape((4,4,4,filters*16))(f1)
    

    # Percorso di espansione
    c5 = tf.keras.layers.Conv3D(filters*8, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(f2)
    c5 = tf.keras.layers.Dropout(0.2)(c5)
    c5 = tf.keras.layers.Conv3D(filters*8, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c5)
    c5 = tf.keras.layers.Dropout(0.2)(c5)
    c5 = tf.keras.layers.Conv3D(filters*8, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c5)

    u6 = tf.keras.layers.Conv3DTranspose(filters*4, (2, 2, 2), strides=(2, 2, 2), padding='same')(c5)

    c6 = tf.keras.layers.Conv3D(filters*4, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(u6)
    c6 = tf.keras.layers.Dropout(0.2)(c6)
    c6 = tf.keras.layers.Conv3D(filters*4, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c6)
    c6 = tf.keras.layers.Dropout(0.2)(c6)
    c6 = tf.keras.layers.Conv3D(filters*4, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c6)

    u7 = tf.keras.layers.Conv3DTranspose(filters*2, (2, 2, 2), strides=(2, 2, 2), padding='same')(c6)

    c7 = tf.keras.layers.Conv3D(filters*2, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(u7)
    c7 = tf.keras.layers.Dropout(0.2)(c7)
    c7 = tf.keras.layers.Conv3D(filters*2, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c7)
    c7 = tf.keras.layers.Dropout(0.2)(c7)
    c7 = tf.keras.layers.Conv3D(filters*2, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c7)

    u8 = tf.keras.layers.Conv3DTranspose(filters, (2, 2, 2), strides=(2, 2, 2), padding='same')(c7)

    c8 = tf.keras.layers.Conv3D(filters, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(u8)
    c8 = tf.keras.layers.Dropout(0.2)(c8)
    c8 = tf.keras.layers.Conv3D(filters, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c8)
    c8 = tf.keras.layers.Dropout(0.2)(c8)
    c8 = tf.keras.layers.Conv3D(filters, (3, 3, 3), activation='relu', kernel_initializer='he_normal', padding='same')(c8)

    outputs = tf.keras.layers.Conv3D(1, kernel_size=(1, 1, 1), activation=None)(c8)

    model = tf.keras.Model(inputs=[inputs], outputs=[outputs])

    return model