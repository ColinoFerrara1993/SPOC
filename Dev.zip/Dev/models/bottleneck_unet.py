import tensorflow as tf

#model Unet with bottleneck
def downward_block(input, filters=filters, activation=None, kernel_size=3, padding='same'):
            
    c=tf.keras.layers.Conv3D(filters=filters, activation=activation, kernel_size=kernel_size, padding=padding)(input)
    c=tf.keras.layer.BatchNormalization()(c)
    c=tf.keras.layer.LeakyReLU()(c)
    c=tf.keras.layers.Conv3D(filters=filters, activation=activation, kernel_size=kernel_size, padding=padding)(c)
    c=tf.keras.layer.BatchNormalization()(c)
    c=tf.keras.layer.LeakyReLU()(c)
    return c

def downsample_block(input, filters=filters, activation=None, kernel_size=3, padding='same'):
    return nn.Sequential(
            nn.Conv3d(out_channels, out_channels, kernel_size=3, stride=2, padding=(1,1,1)),
            nn.BatchNorm3d(out_channels),
            nn.LeakyReLU(),
        )

def bottleneck_block(in_channels, out_channels):
    return nn.Sequential(
            nn.Conv3d(in_channels, out_channels, kernel_size=3, padding='same'),
            nn.BatchNorm3d(out_channels),
            nn.LeakyReLU(),
            nn.Conv3d(out_channels, out_channels, kernel_size=3, padding='same'),
            nn.BatchNorm3d(out_channels),
            nn.LeakyReLU(),
        )

def bilinear_upsample_block(in_channels, out_channels):
    return nn.Sequential(
            nn.Upsample(scale_factor=2, mode='trilinear', align_corners=True),
            nn.Conv3d(in_channels, out_channels, kernel_size=1, padding='same'),
        )

def upward_block(in_channels):
    return nn.Sequential(
            nn.Conv3d(in_channels, in_channels, kernel_size=3, padding='same'),
            nn.BatchNorm3d(in_channels),
            nn.LeakyReLU(),
            nn.Conv3d(in_channels, in_channels, kernel_size=3, padding='same'),
            nn.BatchNorm3d(in_channels),
            nn.LeakyReLU(),
        )

def final_block(in_channels):
    return nn.Sequential(
            nn.Conv3d(in_channels, in_channels, kernel_size=3, padding='same'),
            nn.BatchNorm3d(in_channels),
            nn.LeakyReLU(),
            nn.Conv3d(in_channels, 1, kernel_size=3, padding='same'),
        )

class UNetnew(nn.Module):
    def __init__(self, n_channels=[4, 8, 16, 32, 64]):
        super().__init__()
        self.downward_block1 = downward_block(1, n_channels[0])
        self.downward_block2 = downward_block(n_channels[0], n_channels[1])
        self.downward_block3 = downward_block(n_channels[1], n_channels[2])
        self.downward_block4 = downward_block(n_channels[2], n_channels[3])
        self.downsample_block1 = downsample_block(n_channels[0])
        self.downsample_block2 = downsample_block(n_channels[1])
        self.downsample_block3 = downsample_block(n_channels[2])
        self.downsample_block4 = downsample_block(n_channels[3])
        self.bottleneck_block = bottleneck_block(n_channels[3], n_channels[4])
        self.upsample_block1 = bilinear_upsample_block(n_channels[4], n_channels[3])
        self.upsample_block2 = bilinear_upsample_block(n_channels[3], n_channels[2])
        self.upsample_block3 = bilinear_upsample_block(n_channels[2], n_channels[1])
        self.upsample_block4 = bilinear_upsample_block(n_channels[1], n_channels[0])
        self.upward_block1 = upward_block(n_channels[3])
        self.upward_block2 = upward_block(n_channels[2])
        self.upward_block3 = upward_block(n_channels[1])
        self.final_block = final_block(n_channels[0])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x1 = self.downward_block1(x)
        x = self.downsample_block1(x1)
        x2 = self.downward_block2(x)
        x = self.downsample_block2(x2)
        x3 = self.downward_block3(x)
        x = self.downsample_block3(x3)
        x4 = self.downward_block4(x)
        x = self.downsample_block4(x4)
        x = self.bottleneck_block(x)
        x = self.upsample_block1(x) + x4
        x = self.upward_block1(x)
        x = self.upsample_block2(x) + x3
        x = self.upward_block2(x)
        x = self.upsample_block3(x) + x2
        x = self.upward_block3(x)
        x = self.upsample_block4(x) + x1
        x = self.final_block(x)
        return x