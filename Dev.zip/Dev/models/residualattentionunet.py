import tensorflow as tf

#model Residual Attention Unet
def channel_att_module(input , ratio = 16):
    _,_,_,_,c = input.shape
    x = tf.keras.layers.GlobalAveragePooling3D()(input)
    x = tf.keras.layers.Dense(c//ratio, activation = "relu", use_bias=False)(x)
    x = tf.keras.layers.Dense(c , activation = "sigmoid", use_bias=False)(x)
    return input * x[: , tf.newaxis, tf.newaxis, tf.newaxis, :]

def spatial_att_module(input , num_filters):
    x = tf.keras.layers.Conv3D(num_filters, kernel_size = (1,1) , padding = "same" , activation = "relu", use_bias = True)(input)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv3D(num_filters, kernel_size = (3,3) , padding = "same" , activation = "sigmoid", use_bias = False)(x)
    return input * x[: ,: ,: ,: ,:]

def res_multiconv_att_module(input , num_filters):
    x1 = tf.keras.layers.Conv3D(num_filters, kernel_size = (1,1) , padding = "same" ,activation = "relu", use_bias = True )(input)
    x2 = tf.keras.layers.Conv3D(num_filters, kernel_size = (1,1) , padding = "same" , activation = "relu", use_bias = True)(input)
    x3 = tf.keras.layers.Conv3D(num_filters, kernel_size = (1,1) , padding = "same" , activation = "relu", use_bias = True)(input)
    x4 = tf.keras.layers.Conv3D(num_filters, kernel_size = (1,1) , padding = "same" , activation = "relu", use_bias = True)(input)

    x22 = tf.keras.layers.Conv3D(num_filters, kernel_size = (3,3) , padding = "same" , activation = "relu", use_bias = True)(x2)
    x32 = tf.keras.layers.Conv3D(num_filters, kernel_size = (5,5) , padding = "same" , activation = "relu", use_bias = True)(x3)

    x = tf.keras.layers.Concatenate()([x1,x22,x32,x4])
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv3D(num_filters, kernel_size = (3,3) ,padding= "same" , activation = "relu", use_bias = True)(x)
    x = tf.keras.layers.BatchNormalization()(x)

    #skip connections
    skip = tf.keras.layers.Conv3D(num_filters, kernel_size=(1, 1), kernel_initializer='he_normal', padding='same')(input)
    skip = tf.keras.layers.BatchNormalization()(skip)
    skip = tf.keras.layers.Activation("relu")(skip)
    res = tf.keras.layers.add([skip, x])
    return res

def mdag_module(input, up_sampled, num_filters):
    a = channel_att_module(input)
    a = spatial_att_module(a, num_filters)

    shape_input = tf.keras.backend.int_shape(input)
    shape_up = tf.keras.backend.int_shape(up_sampled)

    x = tf.keras.layers.Conv3D(num_filters, kernel_size = (2,2) , strides = (2,2) , padding = "same" , activation = "sigmoid", use_bias = False)(a)

    shape_x1 = tf.keras.backend.int_shape(x)

    y = tf.keras.layers.Conv3D(num_filters, kernel_size = (1,1) , padding = "same" , activation = "relu", use_bias = False)(up_sampled)
    y = tf.keras.layers.Conv3DTranspose(num_filters, kernel_size = (3, 3), strides=(shape_x1[1] // shape_up[1], shape_x1[2] // shape_up[2]), kernel_initializer='he_normal', padding='same')(y)

    conc = tf.keras.layers.Concatenate()([y, x])
    _,_,_,_,c = conc.shape
    conc = tf.keras.layers.Dense(c, activation = "relu", use_bias=True)(conc)
    conc = tf.keras.layers.Conv3D(1, kernel_size = (1,1) , padding = "same" , activation = "sigmoid", use_bias = False)(conc)
    _,_,_,_,d = conc.shape
    conc = tf.keras.layers.Dense(d, activation = "sigmoid", use_bias=True)(conc)
    shape_sigmoid = tf.keras.backend.int_shape(conc)
    conc = tf.keras.layers.UpSampling3D(size=(shape_input[1] // shape_sigmoid[1], shape_input[2] // shape_sigmoid[2]))(conc)

    output = tf.keras.layers.multiply([conc, a])
    output = tf.keras.layers.Conv3D(shape_input[3], kernel_size = (1,1) , padding = "same" , activation = "relu", use_bias = True)(output)
    output = tf.keras.layers.BatchNormalization()(output)
    return output

def encoder(input, num_filters):
    x = res_multiconv_att_module(input , num_filters)
    m = tf.keras.layers.MaxPool3D((2,2))(x)
    return x , m

def decoder(input, up_sampled , num_filters):
    y = tf.keras.layers.UpSampling3D((2,2), data_format = "channels_last")(up_sampled)
    y = tf.keras.layers.Concatenate()([ y, input])
    x = res_multiconv_att_module(y, num_filters)
    return x

def build_model(input_shape,  n_classes):

    inputs = tf.keras.layers.Input(input_shape)

    s1,p1 = encoder(inputs,16)
    s2,p2 = encoder(p1,32)
    s3,p3 = encoder(p2,64)
    s4,p4 = encoder(p3,128)

    b0 = res_multiconv_att_module(p4,256)

    m0 = mdag_module(s4,b0,128)
    d1 = decoder(m0,b0,128)

    m1 = mdag_module(s3,d1, 64)
    d2 = decoder(m1,d1,64)

    m2 = mdag_module(s2,d2, 32)
    d3 = decoder(m2,d2,32)

    m3 = mdag_module(s1,d3, 16)
    d4 = decoder(m3,d3,16)

    d5 = tf.keras.layers.Conv3D(1, (1,1) , padding = "same")(d4)
    d5 = tf.keras.layers.BatchNormalization()(d5)

    outputs = tf.keras.layers.Conv3D(n_classes,(1,1),padding = "same", activation='softmax')(d5)

    model = tf.keras.Model(inputs, outputs, name="residualattentionunet")
    
    return model