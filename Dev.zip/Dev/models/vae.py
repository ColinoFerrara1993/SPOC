import tensorflow as tf

# Modello VAE standard
def get_model(filters=32):
# Encoder
    input_image = tf.keras.layers.Input(shape=(32, 32, 32, 1))

# Strati convoluzionali per l'encoder
    x = tf.keras.layers.Conv3D(filters, (3, 3, 3), activation='relu', strides=(2, 2, 2), padding='same')(input_image)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv3D(filters*2, (3, 3, 3), activation='relu', strides=(2, 2, 2), padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv3D(filters*4, (3, 3, 3), activation='relu', strides=(2, 2, 2), padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv3D(filters*8, (3, 3, 3), activation='relu', strides=(2, 2, 2), padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv3D(filters*16, (3, 3, 3), activation='relu', strides=(2, 2, 2), padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(x)

# Bottleneck
    bottleneck = tf.keras.layers.Conv3D(filters*32, (3, 3, 3), activation='relu', padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(bottleneck)

# Decoder (Deconvoluzioni)
    x = tf.keras.layers.Conv3DTranspose(filters*16, (3, 3, 3), activation='relu', strides=(2, 2, 2), padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv3DTranspose(filters*8, (3, 3, 3), activation='relu', strides=(2, 2, 2), padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv3DTranspose(filters*4, (3, 3, 3), activation='relu', strides=(2, 2, 2), padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv3DTranspose(filters*2, (3, 3, 3), activation='relu', strides=(2, 2, 2), padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv3DTranspose(filters, (3, 3, 3), activation='relu', strides=(2, 2, 2), padding='same')(x)
    x = tf.keras.layers.BatchNormalization()(x)

# Uscita
    output_image = tf.keras.layers.Conv3D(1, (3, 3, 3), activation='sigmoid', padding='same')(x)

# Modello
    autoencoder = tf.keras.Model(input_image, output_image)

    return autoencoder