import tensorflow as tf

# Modello CNN standard
def get_model(filters=32):

    # Creiamo il modello CNN
    model = tf.keras.models.Sequential()

    # Primo strato convoluzionale
    model.add(tf.keras.layers.Conv3D(filters, kernel_size=(3, 3, 3), activation='relu', padding='same', input_shape=(32, 32, 32, 1)))

    # Strato di normalizzazione batch
    model.add(tf.keras.layers.BatchNormalization())

    # Secondo strato convoluzionale
    model.add(tf.keras.layers.Conv3D(filters*2, kernel_size=(3, 3, 3), activation='relu', padding='same'))

    # Strato di normalizzazione batch
    model.add(tf.keras.layers.BatchNormalization())

    # Terzo strato convoluzionale
    model.add(tf.keras.layers.Conv3D(filters*4, kernel_size=(3, 3, 3), activation='relu', padding='same'))

    # Strato di normalizzazione batch
    model.add(tf.keras.layers.BatchNormalization())

    # Strato di upsampling per mantenere la dimensione dell'output
    #model.add(tf.keras.layers.UpSampling3D(size=(2, 2, 2)))

    # Ultimo strato convoluzionale per riportare l'immagine alla stessa dimensione (32, 32, 32)
    model.add(tf.keras.layers.Conv3D(1, kernel_size=(3, 3, 3), activation='sigmoid', padding='same'))

    return model
