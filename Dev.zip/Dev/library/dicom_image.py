import enum
import kornia
import torch
import tensorflow as tf
from typing import Optional
import SimpleITK as sitk
import numpy as np
import kornia
from kornia.augmentation import RandomRotation3D, RandomAffine3D


def resample_img(itk_image, new_spacing, is_label):
    if np.all([x is None for x in new_spacing]):
        return itk_image

    spacing = itk_image.GetSpacing()

    size = list(itk_image.GetSize())
    spacing = list(spacing)

    for i in range(3):
        if new_spacing[i] is not None:
            size[i] = int(np.round(size[i] * (spacing[i] / new_spacing[i])))
            spacing[i] = new_spacing[i]

    resampler = sitk.ResampleImageFilter()
    resampler.SetOutputSpacing(spacing)
    resampler.SetSize(size)
    resampler.SetOutputDirection(itk_image.GetDirection())
    resampler.SetOutputOrigin(itk_image.GetOrigin())
    resampler.SetTransform(sitk.Transform())

    if is_label:
        resampler.SetDefaultPixelValue(0)
        resampler.SetOutputPixelType(sitk.sitkUInt8)
        resampler.SetInterpolator(sitk.sitkNearestNeighbor)

    else:
        min_maxfilter = sitk.MinimumMaximumImageFilter()
        min_maxfilter.Execute(itk_image)
        min = min_maxfilter.GetMinimum()
        resampler.SetDefaultPixelValue(min)
        resampler.SetOutputPixelType(sitk.sitkFloat32)
        resampler.SetInterpolator(sitk.sitkLinear) #o Spline (più lento)

    return resampler.Execute(itk_image)

def downsamplePatient(ct, resize_factor):
    patient_CT = ct

    reader = sitk.ImageSeriesReader()
    dicom_names = reader.GetGDCMSeriesFileNames(patient_CT)
    reader.SetFileNames(dicom_names)

    original_CT = reader.Execute()
    
    
    dimension = original_CT.GetDimension()
    reference_physical_size = np.zeros(original_CT.GetDimension())
    reference_physical_size[:] = [(sz-1)*spc if sz*spc>mx  else mx for sz,spc,mx in zip(original_CT.GetSize(), original_CT.GetSpacing(), reference_physical_size)]
    
    reference_origin = original_CT.GetOrigin()
    reference_direction = original_CT.GetDirection()

    reference_size = [round(sz/resize_factor) for sz in original_CT.GetSize()] 
    reference_spacing = [ phys_sz/(sz-1) for sz,phys_sz in zip(reference_size, reference_physical_size) ]

    reference_image = sitk.Image(reference_size, original_CT.GetPixelIDValue())
    reference_image.SetOrigin(reference_origin)
    reference_image.SetSpacing(reference_spacing)
    reference_image.SetDirection(reference_direction)

    reference_center = np.array(reference_image.TransformContinuousIndexToPhysicalPoint(np.array(reference_image.GetSize())/2.0))
    
    transform = sitk.AffineTransform(dimension)
    transform.SetMatrix(original_CT.GetDirection())

    transform.SetTranslation(np.array(original_CT.GetOrigin()) - reference_origin)
  
    centering_transform = sitk.TranslationTransform(dimension)
    img_center = np.array(original_CT.TransformContinuousIndexToPhysicalPoint(np.array(original_CT.GetSize())/2.0))
    centering_transform.SetOffset(np.array(transform.GetInverse().TransformPoint(img_center) - reference_center))
    centered_transform = sitk.CompositeTransform(transform)
    centered_transform.AddTransform(centering_transform)
    
    return sitk.Resample(original_CT, reference_image, centered_transform, sitk.sitkLinear, 0.0)

class Normalization(enum.Enum):
    MINMAX = None
    ZSCORE = None

class DicomImage():
    def __init__(self, image_path: str, label_path: str, new_spacing:
                 tuple[Optional[float], Optional[float], Optional[float]]) -> None:

        self.size = (32,32,32)
        #image = sitk.ReadImage(image_path)
        #label = sitk.ReadImage(label_path)

        #image = resample_img(image, new_spacing, False)
        #label = resample_img(label, new_spacing, True)

        image = downsamplePatient(image_path, 4)
        label = downsamplePatient(label_path, 4)

        # axes: x, y, z
        self.image = sitk.GetArrayFromImage(image)
        self.label = sitk.GetArrayFromImage(label)

        # Tensor for augmentation
        self.images_aug = np.empty(
            (1, self.size[0], self.size[1], self.size[2]), dtype=np.float32)
        self.labels_aug = np.empty(
            (1, self.size[0], self.size[1], self.size[2]), dtype=np.float32)
        
        self.images_aug[0,:,:,:] = self.image

        self.labels_aug[0,:,:,:] = self.label

    def non_bg_range(self) -> tuple[int, int]:
        index = np.argwhere(np.any(self.label != 0, axis=(1, 2)))

        min_slice = np.min(index)
        max_slice = np.max(index)

        return (min_slice, max_slice)

    def remove_bg_slices(self, margin: int) -> None:
        min_slice, max_slice = self.non_bg_range()

        min_slice = min_slice - margin
        max_slice = max_slice + margin

        self.image = self.image[min_slice:max_slice + 1, :, :]
        self.label = self.label[min_slice:max_slice + 1, :, :]

    def windowing(self, min_value: int, max_value: int) -> None:
        self.image = np.clip(self.image, min_value, max_value)

    def normalize(self, type: Normalization) -> None:
        if type == Normalization.MINMAX:
            self.image = self.image - np.min(self.image)
            self.image = self.image / (np.ptp(self.image))
            self.label = self.label - np.min(self.label)
            self.label = self.label / (np.ptp(self.label))
        elif type == Normalization.ZSCORE:
            self.image = self.image - np.mean(self.image)
            self.image = self.image / (np.std(self.image))
            self.label = self.label - np.mean(self.label)
            self.label = self.label / (np.std(self.label))

    def center(self, label_class: int) -> tuple[int, int]:
        pixels = self.label == label_class

        x = int(np.mean(np.argwhere(np.any(pixels, axis=(0, 1)))))
        y = int(np.mean(np.argwhere(np.any(pixels, axis=(0, 2)))))

        return (x, y)

    def crop(self, center: tuple[int, int], size: tuple[int, int]) -> None:

        # x, y
        img_size = (self.image.shape[2], self.image.shape[1])

        lim = []

        for i in range(2):
            if center[i] - size[i] // 2 - 1 < 0:
                lim.append((0, size[i]))
            elif center[i] + size[i] // 2 + 1 > img_size[i]:
                lim.append((img_size[i] - size[i], img_size[i]))
            else:
                start = center[i] - size[i] // 2
                lim.append((start, start + size[i]))

        self.image = self.image[:, lim[1][0]:lim[1][1], lim[0][0]:lim[0][1]]
        self.label = self.label[:, lim[1][0]:lim[1][1], lim[0][0]:lim[0][1]]

    
    def rotation(self,
                 degrees: tuple[float,float,float],
                 p: float):
        
        aug = kornia.augmentation.RandomRotation3D(degrees, p=p)

        #(aug(self.labels_aug) == aug(self.labels_aug, params=aug._params)).all()

        return (aug(self.images_aug),aug(self.labels_aug, params=aug._params))
    
    def traslation(self,
                 degrees: tuple[float,float,float],
                 translate: tuple[float,float,float],
                 p: float):
        
        aug = kornia.augmentation.RandomAffine3D(degrees, translate, p=p)

        return (aug(self.images_aug),aug(self.labels_aug, params=aug._params))
 