import os

dataset_base_path = os.path.expandvars('database')

images_dir = 'images'
labels_dir = 'labels'

geo1_dir = 'dicom_2sphere'
geo2_dir = 'dicom_C'
geo3_dir = 'dicom_cross'
geo4_dir = 'dicom_ring'

images_path = os.path.join(dataset_base_path, images_dir)
labels_path = os.path.join(dataset_base_path, labels_dir)

geo1_im_path = os.path.join(images_path, geo1_dir)
geo2_im_path = os.path.join(images_path, geo2_dir)
geo3_im_path = os.path.join(images_path, geo3_dir)
geo4_im_path = os.path.join(images_path, geo4_dir)

geo1_lb_path = os.path.join(labels_path, geo1_dir)
geo2_lb_path = os.path.join(labels_path, geo2_dir)
geo3_lb_path = os.path.join(labels_path, geo3_dir)
geo4_lb_path = os.path.join(labels_path, geo4_dir)