import numpy as np
import torch
import tensorflow as tf
import nibabel as nib
import skimage
import SimpleITK as sitk

from library import dicom_image

class NiiFilesDataset(tf.keras.utils.Sequence):
    def __init__(self) -> None:

        self.batch_size = 4

        self.normalize = None

        self.rotation = None

        self.traslation = None

        self.random_seed = 1234

        self.shuffle = None

        self.random_shift = None

        self.size = (32,32,32)
        
        self.aug_tuple = (180.,180.,180.)

        self.aug2_tuple = (1.,1.,1.)

        self.trans_tuple = (0.5,0.5,0.5)

        self.p = 1.

    def load(self, images: list[str], labels: list[str]) -> None:

        self.rng = np.random.default_rng(seed=self.random_seed)

        samples_ = [dicom_image.DicomImage(image, label, (None, None, None))
                   for image, label in zip(images, labels)]
        
        #self.rng.shuffle(samples_)

        # Number of samples
        self.N = int(np.sum([1 for sample in samples_]))
        #print(self.N)

        # Number of object augmented for every original image
        self.F = 200

        # Tensor 
        self.images = np.empty(
            (self.N*self.F, self.size[0], self.size[1], self.size[2]), dtype=np.float32)
        self.labels = np.empty(
            (self.N*self.F, self.size[0], self.size[1], self.size[2]), dtype=np.float32)
        
        ll=0
        for sample in samples_:

            if self.normalize is not None:
                sample.normalize(self.normalize)

            self.images[ll, :, :, :] = sample.image

            self.labels[ll, :, :, :] = sample.label

            for it_1 in range(1,self.F//2):

                if self.rotation is not None:

                    (im_rot,lb_rot) = sample.rotation(self.aug_tuple,self.p)

                    self.images[ll+it_1, :, :, :] = im_rot[0][0]

                    self.labels[ll+it_1, :, :, :] = lb_rot[0][0]

            for it_2 in range((self.F//2)+1,self.F):

                if self.traslation is not None:

                    (im_tr,lb_tr) = sample.traslation(self.aug2_tuple, self.trans_tuple, self.p)

                    self.images[ll+it_2, :, :, :] = im_tr[0][0]

                    self.labels[ll+it_2, :, :, :] = lb_tr[0][0]

            ll = ll + self.F

        # Index of samples, for shuffling
        self.index = np.arange(self.N*self.F, dtype=int)

        # per mischiare i campioni anche alla prima epoca
        self.on_epoch_end()

    def __len__(self):
        return len(self.index) // self.batch_size

    def __getitem__(self, idx):

        low = idx * self.batch_size
        high = low + self.batch_size

        #images_batch = self.images[self.index[low:high], ...]
        #labels_batch = self.labels[self.index[low:high], ...]

        images_batch = np.expand_dims(self.images[self.index[low:high], ...], axis=-1)
        labels_batch = np.expand_dims(self.labels[self.index[low:high], ...], axis=-1)

        images = np.empty((self.batch_size, self.size[0],
                           self.size[1], self.size[2],1), dtype=np.float32)
        labels = np.empty((self.batch_size, self.size[0],
                           self.size[1], self.size[2],1), dtype=np.float32)
        
        for i in range(self.batch_size):

            images[i] = images_batch[i]

            labels[i] = labels_batch[i]

        return (images,labels)

    def on_epoch_end(self):
        if self.shuffle:
            self.rng.shuffle(self.index)
