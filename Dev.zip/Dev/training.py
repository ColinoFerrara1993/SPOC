import os
import numpy as np
import tensorflow as tf
import library.paths
import library.dataset
import library.dicom_image

import models.vae

import metrics.iou
import metrics.psnr
import metrics.ssim


samples = [f for f in os.listdir(library.paths.labels_path) if f.startswith('dicom_')]

images = [os.path.join(library.paths.images_path, f) for f in samples]
labels = [os.path.join(library.paths.labels_path, f) for f in samples]

n_splits = 2

limits = np.linspace(0, len(samples), n_splits + 1).astype(int)

iou_scores = []

def MyIoU(y_true, y_pred):
        y_true = tf.keras.ops.nonzero(y_true, axis=-1)
        y_pred = tf.keras.ops.nonzero(y_pred, axis=-1)
        IoU_sum = 0
        intersection = tf.reduce_sum(tf.cast((y_true == 1) & (y_pred == 1), tf.float32))
        union = tf.reduce_sum(tf.cast((y_true == 1) | (y_pred == 1), tf.float32))
        IoU_sum += intersection / union
        return IoU_sum

for i in range(n_splits):
    print(f"Fold {i}:")

    train_dataset = library.dataset.NiiFilesDataset()
    train_dataset.normalize = library.dicom_image.Normalization.MINMAX
    train_dataset.shuffle = True
    train_dataset.random_shift = True
    train_dataset.rotation = True
    train_dataset.traslation = True

    val_dataset = library.dataset.NiiFilesDataset()
    val_dataset.normalize = library.dicom_image.Normalization.MINMAX
    val_dataset.shuffle = False
    val_dataset.random_shift = False
    val_dataset.rotation = False
    val_dataset.traslation = False

    train_dataset.load(images[:limits[i]] + images[limits[i + 1]:],
                       labels[:limits[i]] + labels[limits[i + 1]:])

    val_dataset.load(images[limits[i]:limits[i + 1]],
                     labels[limits[i]:limits[i + 1]])

    model = models.vae.get_model()


    #LOSS
    mae = tf.keras.losses.MeanAbsoluteError(name="mean_squared_error", dtype=np.float32)


    #METRICS
    mse = tf.keras.metrics.MeanSquaredError(name="mean_squared_error", dtype=np.float32)
    ssim = metrics.ssim.metric_ssim()
    psnr = metrics.psnr.metric_psnr()
    iou = metrics.iou.Miou()

    model.compile(optimizer='adam', 
                loss=mae,
                metrics=[iou, psnr, ssim, mse])

    print(len(train_dataset))
    print(len(val_dataset))

    model.fit(train_dataset, epochs=100,
            validation_data=val_dataset,
            verbose=2
    )

    model.save(f'test_vae11_model_fold_{i}.hdf5')

    #pred = np.argmax(model.predict(val_dataset, verbose=2), axis=-1)
    pred = model.predict(val_dataset, verbose=2)

    y_true = [batch[1] for batch in val_dataset]
    y_true = np.concatenate(y_true)
    #y_true = np.argmax(y_true, axis=-1)

    iou_scores.append(MyIoU(y_true, pred))

    print(iou_scores[-1])

print(iou_scores)
print(np.mean(iou_scores))
print(np.std(iou_scores.sum))
