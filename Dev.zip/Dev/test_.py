# %%
import os
import numpy as np
import tensorflow as tf
import library.paths
import library.dataset
import models.models
import library.dicom_image

samples = [f for f in os.listdir(library.paths.labels_path) if f.startswith('dicom_')]
# %%
rng = np.random.default_rng(0)


rng.shuffle(samples)
# %%
images = [os.path.join(library.paths.images_path, f) for f in samples]
labels = [os.path.join(library.paths.labels_path, f) for f in samples]

n_splits = 4

limits = np.linspace(0, len(samples), n_splits + 1).astype(int)
# %%
dice_scores = []

def dice_coef(y_true, y_pred):
    intersection = np.sum(y_true * y_pred)
    return (2. * intersection) / (np.sum(y_true) + np.sum(y_pred))

for i in range(n_splits):
    print(f"Fold {i}:")
# %%
    train_dataset = library.dataset.NiiFilesDataset()
    train_dataset.normalize = library.dicom_image.Normalization.MINMAX
    train_dataset.shuffle = True
    train_dataset.random_shift = True
    train_dataset.rotation = True
    train_dataset.traslation = True
# %%
    val_dataset = library.dataset.NiiFilesDataset()
    val_dataset.normalize = library.dicom_image.Normalization.MINMAX
    val_dataset.shuffle = True
    val_dataset.random_shift = True
    val_dataset.rotation = True
    val_dataset.traslation = True
# %%
    train_dataset.load(images[:limits[i]] + images[limits[i + 1]:],
                       labels[:limits[i]] + labels[limits[i + 1]:])
# %%
    val_dataset.load(images[limits[i]:limits[i + 1]],
                     labels[limits[i]:limits[i + 1]])
# %%
    model = models.models.get_model()

    rmse = tf.keras.metrics.RootMeanSquaredError(name="root_mean_squared_error", dtype=None)
    mape = tf.keras.losses.MeanAbsolutePercentageError(reduction="sum_over_batch_size", name="mean_absolute_percentage_error", dtype=None)

    model.compile(optimizer='adam', 
                loss=mape,
                metrics=[rmse])

    print(len(train_dataset))
    print(len(val_dataset))

    model.fit(train_dataset, epochs=500,
            validation_data=val_dataset,
            verbose=2
    )

    model.save(f'test_model_fold_{i}.hdf5')

    pred = np.argmax(model.predict(val_dataset, verbose=2), axis=-1)

    y_true = [batch[1] for batch in val_dataset]
    y_true = np.concatenate(y_true)
    y_true = np.argmax(y_true, axis=-1)

    dice_scores.append(dice_coef(y_true, pred))

    print(dice_scores[-1])

print(dice_scores)
print(np.mean(dice_scores))
print(np.std(dice_scores))
# %%
import matplotlib.pyplot as plt
k = 16

fig, ax = plt.subplots(1, 1)
ax.imshow(im[0][k], cmap='Grays')
# %%
fig, ax = plt.subplots(1, 1)
ax.imshow(lb[0][k], cmap='Grays')
# %%
val_dataset = library.dataset.NiiFilesDataset()
val_dataset.intensity_windowing = (-100, 240)
val_dataset.normalize = pnrr_lib.nii_image.Normalization.MINMAX
val_dataset.exclude_bg_only = False
val_dataset.classes = {0: 0, 1: 0, 2: 1}
val_dataset.shuffle = False
val_dataset.random_shift = False

val_dataset.load(images[limits[i]:limits[i + 1]][j:j+1],
                 labels[limits[i]:limits[i + 1]][j:j+1])
# %%
#i = 0
model = tf.keras.models.load_model(f'test_vae2_model_fold_0_ok.hdf5')

pred = model.predict(val_dataset)
# %%
import matplotlib.pyplot as plt
k=16
fig, ax = plt.subplots(1, 1)
ax.imshow(pred[3][k], cmap='Grays')

# %%
