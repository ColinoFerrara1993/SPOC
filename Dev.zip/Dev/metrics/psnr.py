import tensorflow as tf
from tensorflow import keras

def metric_psnr():

    def psnr_(y_true,y_pred):

        #tf.keras.backend.set_image_data_format('channels_first')

        psnr2 = tf.image.psnr(y_true,y_pred, max_val=1.0, name=None)
        return psnr2
    return psnr_