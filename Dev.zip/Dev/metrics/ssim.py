import tensorflow as tf
from tensorflow import keras

def metric_ssim():

    def ssim_(y_true,y_pred):

        #ssim_none = ssim(y_true.numpy(), y_pred.numpy(), data_range=1.)
        ssim2 = tf.image.ssim(y_true, y_pred, max_val=1.0, filter_size=11,
                          filter_sigma=1.5, k1=0.01, k2=0.03)
        return ssim2
    return ssim_
