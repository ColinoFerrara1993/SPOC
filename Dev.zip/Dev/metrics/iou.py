import tensorflow as tf
from tensorflow import keras

def Miou():
    def MyIoU(y_true, y_pred):
        y_true = tf.argmax(y_true, axis=-1)
        y_pred = tf.argmax(y_pred, axis=-1)
        IoU_sum = 0
        for i in range(1,2):
            intersection = tf.reduce_sum(tf.cast((y_true == i) & (y_pred == i), tf.float32))
            union = tf.reduce_sum(tf.cast((y_true == i) | (y_pred == i), tf.float32))
            IoU_sum += intersection / union
        return IoU_sum
    return MyIoU
